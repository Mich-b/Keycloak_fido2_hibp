import * as React from "../../../common/keycloak/web_modules/react.js";
export const AccountServiceContext = React.createContext(undefined);
//# sourceMappingURL=AccountServiceContext.js.map